//:Create a Submenu for given parent page
//:cat_submenu?parent=<PAGE_ID>
return CAT_Helper_Menu::subMenu($parent);