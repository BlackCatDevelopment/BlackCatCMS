//:Shows an [Edit Page] link in the frontend
//:Usage: [[editthispage]]This Droplet will show a link to the backend page editor. This is only shown when the user is logged in and has the correct permissions to edit the page in question.
//:Shows an "Edit page" link in the frontend
//:Usage: [[editthispage]]
// This Droplet will show a link to the backend page editor. This is only shown when the user is logged in and has the correct permissions to edit the page in question.

$user = CAT_Users::getInstance();
$str  = "";

if (FRONTEND_LOGIN == 'enabled' && $user->is_authenticated())
{
    if (isset($page_id) && is_numeric($page_id))
        $this_page = $page_id;
    else
        $this_page = CAT_Helper_Page::getDefaultPage();

    $results = $user->db()->query(
        "SELECT * FROM `:prefix:pages` WHERE page_id = :id",
        array('id'=>$this_page)
    );
    $results_array    = $results->fetch();
    $old_admin_groups = explode(',', $results_array['admin_groups']);
    $old_admin_users  = explode(',', $results_array['admin_users']);
    $this_user        = $user->get_group_id();
    $page             = CAT_Helper_Page::properties($this_page);
    $admin_groups     = explode(',', str_replace('_', '', $page['admin_groups']));
    $admin_users      = explode(',', str_replace('_', '', $page['admin_users']));
    $in_group         = FALSE;

    foreach($user->get_groups_id() as $cur_gid)
        if (in_array($cur_gid, $admin_groups))
            $in_group = TRUE;

    if (($in_group) || is_numeric(array_search($this_user, $old_admin_groups)) )
    {
        $str  = '<a href="' . CAT_ADMIN_URL . '/pages/modify.php?page_id='.$this_page;
        $str .= '" target="_blank"><img src="';
        $str .= CAT_THEME_URL . '/images/modify_16.png" alt="';
        $str .= $wb->lang->translate('Modify page') . '" /> '.$wb->lang->translate('Modify page').'</a>';
    }

}
return $str;