//:Puts a Login / Logout box on your page.
//:Use: [[LoginBox]]. Remember to enable frontend login in your website settings.
$return_value = " ";
$fe_login     = CAT_Registry::get('FRONTEND_LOGIN');
$visibility   = CAT_Registry::get('VISIBILITY');
$url          = CAT_Registry::get('LOGIN_URL');
$user_id      = CAT_Users::get_user_id();

if($fe_login == 'enabled')
{
    $l = CAT_Users::getInstance()->lang();
    if($visibility != 'private')
    {
        if(CAT_Users::is_authenticated() && $user_id == '')
        {
            $return_value = '<form name="login" action="'.$url.'" method="post" class="login_table">'
                          . '<h2>'.$l->translate('Login').'</h2>'
                          . '<label for="username">'.$l->translate('Username').'</label>:<br />'
                          . '<input type="text" name="username" /><br />'
                          . '<label for="password">'.$l->translate('Password').'</label>:<br />'
                          . '<input type="password" name="password" /><br />'
                          . '<input type="submit" name="submit" value="'.$l->translate('Login').'" class="dbutton" /><br />'
                          . '<a href="'.CAT_Registry::get('FORGOT_URL').'">'.$l->translate('Forgotten your details?').'</a><br />'
                          ;
        	if(is_numeric(CAT_Registry::get('FRONTEND_SIGNUP')))
        		$return_value .= '<a href="'.CAT_Registry::get('SIGNUP_URL').'">'.$l->translate('Sign-up').'</a>';
    	    $return_value .= '</form>';
        }
        else
        {
            $return_value = '<form name="logout" action="'.$url.'" method="post" class="login_table">'
                          . '<h2>'.$l->translate('Logged-In').'</h2>'
                          . $l->translate('Welcome back').', '.CAT_Users::get_display_name().'<br />'
                          . '<input type="submit" name="submit" value="'.$l->translate('Logout').'" class="dbutton" /><br />'
        	              . '<a href="'.CAT_Registry::get('PREFERENCES_URL').'">'.$l->translate('Preferences').'</a><br />'
        	              . '<a href="'.CAT_ADMIN_URL.'/index.php" target="_blank">'.$l->translate('Administration').'</a>'
        	              . '</form>';
        }
    }
}
return $return_value;
