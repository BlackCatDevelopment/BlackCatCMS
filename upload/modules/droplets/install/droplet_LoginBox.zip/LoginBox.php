//:Puts a Login / Logout box on your page.
//:Use: [[LoginBox]]. Remember to enable frontend login in your website settings.
$return_value = " ";
$fe_login     = CAT_Registry::get('FRONTEND_LOGIN');
$visibility   = CAT_Registry::get('VISIBILITY');
$url          = CAT_Registry::get('LOGIN_URL');
$user_id      = CAT_Users::get_user_id();

if($fe_login == 'enabled')
{
    $l = CAT_Users::getInstance()->lang();
    if($visibility != 'private')
    {
        if(!CAT_Users::is_authenticated() || $user_id == '')
        {
            $username_f = CAT_Helper_Validate::createFieldname('username_');
            $passwd_f = CAT_Helper_Validate::createFieldname('password_');
            $return_value = '<form name="login" action="'.$url.'" method="post" class="login_table">'
                          .'<input type="hidden" name="username_fieldname" value="'.$username_f.'" />'
                          .'<input type="hidden" name="password_fieldname" value="'.$passwd_f.'" />'
                          .'<input type="hidden" name="page_id" value="'.PAGE_ID.'" />'
                          . '<h2>'.$l->translate('Login').'</h2>'
                          . '<label for="'.$username_f.'">'.$l->translate('Username').'</label>'
                          . '<input type="text" name="'.$username_f.'" id="'.$username_f.'" /><br />'
                          . '<label for="'.$passwd_f.'">'.$l->translate('Password').'</label>'
                          . '<input type="password" name="'.$passwd_f.'" id="'.$passwd_f.'" /><br />'
                          . $l->translate('A technical cookie is required for backend login.').'<br />'
                          . '<label for="fc_cookie_allow"><input type="checkbox" name="fc_cookie_allow" id="fc_cookie_allow" /> '.$l->translate('allow').'</label><br />'
                          . '<input type="submit" name="submit_login" value="'.$l->translate('Login').'" class="dbutton" /><br />'
                          . '<a href="'.CAT_Registry::get('FORGOT_URL').'">'.$l->translate('Forgot your details?').'</a><br />'
                          ;
            if(is_numeric(CAT_Registry::get('FRONTEND_SIGNUP'))) {
                $return_value .= '<a href="'.CAT_Registry::get('SIGNUP_URL').'">'.$l->translate('Sign-up').'</a>';
            }
            if(isset($_SESSION['LOGIN_ERROR'])) {
                $return_value .= '<div style="border:1px solid #c00; background-color:#fcc;padding:5px;margin:15px auto;">'.$_SESSION['LOGIN_ERROR'].'</div>';
            }
            $return_value .= '</form>';
        }
        else
        {
            $return_value = '<form name="logout" action="'.str_ireplace('login','logout',$url).'" method="post" class="login_table">'
                          . '<h2>'.$l->translate('Logged-In').'</h2>'
                          . $l->translate('Welcome back').', '.CAT_Users::get_display_name().'<br />'
                          . '<input type="submit" name="submit" value="'.$l->translate('Logout').'" class="dbutton" /><br />'
                          . '<a href="'.CAT_Registry::get('PREFERENCES_URL').'">'.$l->translate('Preferences').'</a><br />'
                          . '<a href="'.CAT_ADMIN_URL.'/index.php" target="_blank">'.$l->translate('Administration').'</a>'
                          . '</form>';
        }
    }
}
return $return_value;

