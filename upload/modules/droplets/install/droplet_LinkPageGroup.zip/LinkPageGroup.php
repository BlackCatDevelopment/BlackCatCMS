//:Creates links for every page of the given group
//:
global $wb, $database;
if(!isset($group) || empty($group)) {
    return $wb->lang->translate('Missing group name');
}
$sql   = 'SELECT link, menu_title FROM '.TABLE_PREFIX.'pages WHERE page_groups = "'.$group.'"'
       . ' OR page_groups REGEXP "^'.$group.',.*"'
       . ' OR page_groups REGEXP ".*,'.$group.'$"';

$res   = $database->query($sql);
$items = array();
if($res->numRows()) {
    while( ( $row = $res->fetchRow(MYSQL_ASSOC) ) !== false ) {
        $items[] = '<a href="'
                 . $wb->page_link($row['link'])
                 . '" title="'.$row['menu_title'].'">'
                 . $row['menu_title'].'</a>';
    }
}
if(count($items)) {
    return implode('<br />',$items);
}