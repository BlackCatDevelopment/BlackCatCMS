//:displays the current year
//:Usage:[[year]]
$datum = date("Y");
return $datum;