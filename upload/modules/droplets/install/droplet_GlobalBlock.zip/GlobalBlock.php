//:allows to include a block globally (in the template, for example); was called [sectionpicker] in WB
//:[[globalblock?block=<BlockID>]]
global $database, $parser;
$content   = '';
$query_sec = $database->query("SELECT `section_id`, `module` FROM `:prefix:sections` WHERE `section_id` = ?", array($block));
if($query_sec->numRows() > 0) {
    $section    = $query_sec->fetch();
    $section_id = $section['section_id'];
    $module     = $section['module'];
    if(file_exists(CAT_Helper_Directory::sanitizePath(CAT_PATH.'/modules/'.$module.'/headers.inc.php')))
    {
        global $mod_headers;
        include CAT_Helper_Directory::sanitizePath(CAT_PATH.'/modules/'.$module.'/headers.inc.php');
        if(isset($mod_headers['frontend']) && isset($mod_headers['frontend']['css']))
        {
            foreach($mod_headers['frontend']['css'] as $item)
            {
                $wb_page_data = str_replace(
                    '</head>',
                    '<link href="'
                        . (
                            ( substr($item['file'],0,4) == 'http' ) ? $item['file'] :
                            CAT_Helper_Validate::sanitize_url(CAT_URL.'/'.$item['file'])
                          )
                        . '" rel="stylesheet" type="text/css" media="screen" />'."\n".'</head>',
                    $wb_page_data
                );
            }
        }
        if(
               isset($mod_headers['frontend'])
            && isset($mod_headers['frontend']['jquery'])
            && isset($mod_headers['frontend']['jquery'][0])
            && isset($mod_headers['frontend']['jquery'][0]['all'])
        ) {
            foreach($mod_headers['frontend']['jquery'][0]['all'] as $item)
            {
                $wb_page_data = str_replace(
                    '</head>',
                    '<script src="'
                        . CAT_Helper_Validate::sanitize_url(CAT_URL.'/modules/lib_jquery/plugins/'.$item)
                        . '" type="text/javascript"></script>'."\n"
                        . '</head>',
                    $wb_page_data
                );
            }
        }
        if(isset($mod_headers['frontend']) && isset($mod_headers['frontend']['js']))
        {
            foreach($mod_headers['frontend']['js'] as $item)
            {
                $wb_page_data = str_replace(
                    '</head>',
                    '<script src="'
                        . (
                            ( substr($item,0,4) == 'http' ) ? $item :
                            CAT_Helper_Validate::sanitize_url(CAT_URL.'/'.$item)
                          )
                        . '" type="text/javascript"></script>'."\n"
                        . '</head>',
                    $wb_page_data
                );
            }
        }
    }
    if(file_exists(CAT_Helper_Directory::sanitizePath(CAT_PATH.'/modules/'.$module.'/languages/'.LANGUAGE.'.php')))
        CAT_Helper_I18n::getInstance()->addFile(LANGUAGE.'.php', CAT_Helper_Directory::sanitizePath(CAT_PATH.'/modules/'.$module.'/languages/'));
    ob_start();
        require CAT_PATH.'/modules/'.$module.'/view.php';
        $content = ob_get_contents();
    ob_clean();
    // insert the module's CSS
    if(file_exists(CAT_Helper_Directory::sanitizePath(CAT_PATH.'/modules/'.$module.'/frontend.css')))
        $wb_page_data = str_replace('</head>','<link href="'.CAT_URL.'/modules/'.$module.'/frontend.css" rel="stylesheet" type="text/css" media="screen" />'."\n".'</head>', $wb_page_data );
    if(file_exists(CAT_Helper_Directory::sanitizePath(CAT_PATH.'/modules/'.$module.'/css/frontend.css')))
        $wb_page_data = str_replace('</head>','<link href="'.CAT_URL.'/modules/'.$module.'/css/frontend.css" rel="stylesheet" type="text/css" media="screen" />'."\n".'</head>', $wb_page_data );
    // insert the module's JS
    if(file_exists(CAT_Helper_Directory::sanitizePath(CAT_PATH.'/modules/'.$module.'/frontend.js')))
        $wb_page_data = str_replace('</head>','<script src="'.CAT_URL.'/modules/'.$module.'/frontend.js" type="text/javascript"></script>'."\n".'</head>', $wb_page_data );
    if(file_exists(CAT_Helper_Directory::sanitizePath(CAT_PATH.'/modules/'.$module.'/js/frontend.js')))
        $wb_page_data = str_replace('</head>','<script src="'.CAT_URL.'/modules/'.$module.'/js/frontend.js" type="text/javascript"></script>'."\n".'</head>', $wb_page_data );
}
return $content;