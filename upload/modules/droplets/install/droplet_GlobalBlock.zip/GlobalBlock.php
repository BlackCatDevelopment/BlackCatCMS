//:allows to include a block globally (in the template, for example); was called [sectionpicker] in WB
//:[[globalblock?block=<BlockID>]]
global $database;
$content = '';
$query_sec = $database->query(sprintf("SELECT section_id,module FROM `%ssections` WHERE section_id = '%s' ", CAT_TABLE_PREFIX, $block));
if($query_sec->numRows() > 0) { 
    $section = $query_sec->fetchRow(MYSQL_ASSOC); 
    $section_id = $section['section_id']; 
    $module = $section['module']; 
    ob_start();
        require(CAT_PATH.'/modules/'.$module.'/view.php'); 
        $content = ob_get_contents();
    ob_clean();
    // insert the module's CSS
    if(file_exists(sanitize_path(CAT_PATH.'/modules/'.$module.'/frontend.css')))
        $wb_page_data = str_replace('</head>','<link href="'.CAT_URL.'/modules/'.$module.'/frontend.css" rel="stylesheet" type="text/css" media="screen" />'."\n".'</head>', $wb_page_data );    	
    // insert the module's JS
    if(file_exists(sanitize_path(CAT_PATH.'/modules/'.$module.'/frontend.js')))
        $wb_page_data = str_replace('</head>','<script src="'.CAT_URL.'/modules/'.$module.'/frontend.js" type="text/javascript"></script>'."\n".'</head>', $wb_page_data );    	
} 
return $content;