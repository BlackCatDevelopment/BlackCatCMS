//:Shows Search Box in the frontend
//:Usage: [[SearchBox]]
// This Droplet will show a search box. You can use it within your template or at any WYSIWYG page section
if (SHOW_SEARCH) {
    global $parser;
    
    // load the CSS file search.box.css
    CAT_Helper_Droplet::register_css(PAGE_ID, 'LEPTON_SearchBox', '', 'search.box.css', '/modules/lib_search/templates/default/');
    // load the JS file search.box.js
    CAT_Helper_Droplet::register_js(PAGE_ID, 'LEPTON_SearchBox', '', 'search.box.js', '/modules/lib_search/templates/default/');
    
    // add the actual needed language file (needed by the template parser)
    CAT_Helper_I18n::getInstance()->addFile(LANGUAGE.'.php', CAT_PATH.'/modules/lib_search/languages/');
    
    // set the template path and enable custom templates
    $parser->setPath(CAT_PATH.'/modules/lib_search/templates/custom');
    $parser->setFallbackPath(CAT_PATH.'/modules/lib_search/templates/default');
    
    // parse the search.box template
    return $parser->get('search.box', array('action' => CAT_URL.'/search/index.php'));
}
else {
    // the search function is not enabled!
    return false;
}