//:this droplets displays standard css of your template file
//:Usage:[[check-css]]
// ---- begin droplet
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "http://www.lepton-cms.org/_packinstall/check-css.txt" );
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$source = curl_exec($ch);
curl_close($ch);
       
return $source;
// end droplet